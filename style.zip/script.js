// Games Data
const gamesList = [
  { id: "basketball", name: "🏀 Basketball Shooter", icon: "fa-basketball-ball", desc: "Drag & shoot hoops", rating: 4.9 },
  { id: "dart", name: "🎯 Dart Throw", icon: "fa-bullseye", desc: "Aim & hit bullseye", rating: 4.8 },
  { id: "catcher", name: "🐱 Cat Catch", icon: "fa-cat", desc: "Catch falling objects", rating: 4.7 },
  { id: "reaction", name: "⚡ Reaction Tester", icon: "fa-bolt", desc: "Click as fast as you can", rating: 4.9 },
  { id: "colorswitch", name: "🎨 Color Switch", icon: "fa-palette", desc: "Match the color", rating: 4.8 },
  { id: "gem", name: "💎 Gem Collector", icon: "fa-gem", desc: "Collect gems, avoid bombs", rating: 4.7 },
  { id: "fish", name: "🐟 Fish Eat Fish", icon: "fa-fish", desc: "Eat smaller fish", rating: 4.8 },
  { id: "coin", name: "🪙 Coin Runner", icon: "fa-coins", desc: "Run & collect coins", rating: 4.9 },
  { id: "space", name: "🔫 Space Shooter", icon: "fa-rocket", desc: "Shoot asteroids", rating: 4.8 }
];

// Generate game cards
const gamesGrid = document.getElementById('gamesGrid');
gamesGrid.innerHTML = '';
gamesList.forEach((game) => {
  gamesGrid.innerHTML += `<div class="game-card" data-game="${game.id}"><div class="game-img"><i class="fas ${game.icon}"></i><div class="game-overlay"><span class="play-now">PLAY NOW 🎮</span></div></div><div class="game-info"><h3>${game.name}</h3><p>${game.desc}</p><div class="game-rating"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas ${game.rating === 4.9 ? 'fa-star' : 'fa-star-half-alt'}"></i><span>${game.rating}</span></div></div></div>`;
});

// Navbar scroll effect
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 50) navbar.classList.add('scrolled');
  else navbar.classList.remove('scrolled');
});

// Back to top
const backToTop = document.getElementById('backToTop');
window.addEventListener('scroll', () => {
  if (window.scrollY > 500) backToTop.classList.add('active');
  else backToTop.classList.remove('active');
});
backToTop.onclick = () => window.scrollTo({ top: 0, behavior: 'smooth' });

// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth' }); }
  });
});

// Active link highlight
const sections = document.querySelectorAll('section');
const navLinks = document.querySelectorAll('.nav-link');
window.addEventListener('scroll', () => {
  let current = '';
  sections.forEach(section => {
    const sectionTop = section.offsetTop - 100;
    if (window.scrollY >= sectionTop) current = section.getAttribute('id');
  });
  navLinks.forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href') === `#${current}`) link.classList.add('active');
  });
});

// Sign In Modal
const signModal = document.getElementById('signModal');
const signInBtn = document.getElementById('signInBtn');
signInBtn.onclick = () => signModal.style.display = 'flex';
document.querySelectorAll('.close-modal').forEach(btn => {
  btn.onclick = () => { signModal.style.display = 'none'; gameModal.style.display = 'none'; };
});
window.onclick = (e) => {
  if (e.target === signModal) signModal.style.display = 'none';
  if (e.target === gameModal) gameModal.style.display = 'none';
};

// Sign In functionality
document.getElementById('signSubmitBtn').onclick = () => {
  const username = document.getElementById('signUsername').value;
  const email = document.getElementById('signEmail').value;
  const password = document.getElementById('signPassword').value;
  const msg = document.getElementById('signMsg');
  if (!username || !email || !password) {
    msg.innerHTML = '❌ Please fill all fields!';
    msg.style.color = '#F43F5E';
  } else {
    msg.innerHTML = `✅ Welcome back, ${username}! 🎮`;
    msg.style.color = '#10B981';
    setTimeout(() => {
      signModal.style.display = 'none';
      document.getElementById('signUsername').value = '';
      document.getElementById('signEmail').value = '';
      document.getElementById('signPassword').value = '';
      msg.innerHTML = '';
    }, 2000);
  }
};

// Game Modal
const gameModal = document.getElementById('gameModal');
const modalTitle = document.getElementById('modalTitle');
const gameContainer = document.getElementById('gameContainer');

// Game click handler
document.querySelectorAll('.game-card').forEach(card => {
  card.addEventListener('click', () => {
    const gameId = card.getAttribute('data-game');
    openGame(gameId);
  });
});

function openGame(gameId) {
  gameModal.style.display = 'flex';
  
  if (gameId === 'basketball') {
    modalTitle.textContent = '🏀 Basketball Shooter';
    gameContainer.innerHTML = `<div class="basketball-court"><div class="hoop"></div><div class="drag-ball" id="dragBall" draggable="true">🏀</div><p id="basketballScore">Score: 0</p><p id="basketballMsg">Drag the ball to the hoop!</p><button class="game-btn" id="resetBasketball">New Game</button></div>`;
    let bbScore = 0;
    const ball = document.getElementById('dragBall');
    ball.addEventListener('dragend', (e) => {
      const x = e.clientX, y = e.clientY;
      const hoop = document.querySelector('.hoop');
      const hoopRect = hoop.getBoundingClientRect();
      if (x > hoopRect.left - 50 && x < hoopRect.right + 50 && y > hoopRect.top - 50 && y < hoopRect.bottom + 50) {
        bbScore++;
        document.getElementById('basketballScore').innerHTML = `Score: ${bbScore}`;
        document.getElementById('basketballMsg').innerHTML = '🏆 SCORE! 🏆';
      } else {
        document.getElementById('basketballMsg').innerHTML = '❌ Missed! Try again!';
      }
    });
    document.getElementById('resetBasketball').onclick = () => openGame('basketball');
  }
  else if (gameId === 'dart') {
    modalTitle.textContent = '🎯 Dart Throw';
    gameContainer.innerHTML = `<div class="dart-board" id="dartBoard"></div><p id="dartScore">Score: 0</p><p id="dartMsg">Click the board to throw!</p><button class="game-btn" id="resetDart">New Game</button>`;
    let dartScore = 0;
    document.getElementById('dartBoard').onclick = (e) => {
      const rect = e.target.getBoundingClientRect();
      const x = e.clientX - rect.left, y = e.clientY - rect.top;
      const centerX = rect.width/2, centerY = rect.height/2;
      const distance = Math.sqrt((x - centerX)**2 + (y - centerY)**2);
      const maxDist = rect.width/2;
      let points = 0;
      if (distance < maxDist * 0.2) points = 100;
      else if (distance < maxDist * 0.4) points = 50;
      else if (distance < maxDist * 0.6) points = 30;
      else if (distance < maxDist * 0.8) points = 10;
      else points = 5;
      dartScore += points;
      document.getElementById('dartScore').innerHTML = `Score: ${dartScore}`;
      document.getElementById('dartMsg').innerHTML = `🎯 Hit! +${points} points!`;
    };
    document.getElementById('resetDart').onclick = () => openGame('dart');
  }
  else if (gameId === 'catcher') {
    modalTitle.textContent = '🐱 Cat Catch';
    gameContainer.innerHTML = `<div class="catcher-area" id="catcherArea"><div class="catcher" id="catcher">🐱</div></div><p id="catcherScore">Score: 0</p><p id="catcherMsg">Move mouse to catch falling items!</p><button class="game-btn" id="resetCatcher">New Game</button>`;
    let catchScore = 0;
    const area = document.getElementById('catcherArea');
    const catcher = document.getElementById('catcher');
    let fallingItems = [];
    area.addEventListener('mousemove', (e) => {
      const rect = area.getBoundingClientRect();
      let x = e.clientX - rect.left - 40;
      x = Math.max(0, Math.min(rect.width - 80, x));
      catcher.style.left = x + 'px';
    });
    function createFallingItem() {
      const item = document.createElement('div');
      item.className = 'falling-item';
      item.innerHTML = ['🐟', '🐭', '🐦', '⭐', '💎'][Math.floor(Math.random()*5)];
      item.style.left = Math.random() * (area.offsetWidth - 30) + 'px';
      item.style.top = '0px';
      area.appendChild(item);
      let pos = 0;
      const interval = setInterval(() => {
        pos += 5;
        item.style.top = pos + 'px';
        const catRect = catcher.getBoundingClientRect();
        const itemRect = item.getBoundingClientRect();
        if (pos > area.offsetHeight - 50 && Math.abs(itemRect.left - catRect.left) < 50) {
          catchScore++;
          document.getElementById('catcherScore').innerHTML = `Score: ${catchScore}`;
          clearInterval(interval);
          item.remove();
        } else if (pos > area.offsetHeight) {
          clearInterval(interval);
          item.remove();
        }
      }, 50);
    }
    let gameInt = setInterval(createFallingItem, 1000);
    document.getElementById('resetCatcher').onclick = () => { clearInterval(gameInt); openGame('catcher'); };
  }
  else if (gameId === 'reaction') {
    modalTitle.textContent = '⚡ Reaction Tester';
    gameContainer.innerHTML = `<div class="reaction-box" id="reactionBox">Click Me!</div><p id="reactionScore">Score: 0</p><p id="reactionMsg">Wait for green, then click fast!</p><button class="game-btn" id="resetReaction">New Game</button>`;
    let reactScore = 0, isGreen = false, timeout;
    const box = document.getElementById('reactionBox');
    function startRound() {
      box.style.background = '#6B7280';
      box.innerHTML = 'Wait...';
      isGreen = false;
      timeout = setTimeout(() => {
        box.style.background = '#10B981';
        box.innerHTML = 'CLICK NOW!';
        isGreen = true;
      }, Math.random() * 3000 + 1000);
    }
    box.onclick = () => {
      if (isGreen) {
        reactScore++;
        document.getElementById('reactionScore').innerHTML = `Score: ${reactScore}`;
        document.getElementById('reactionMsg').innerHTML = '✅ Great reaction!';
        clearTimeout(timeout);
        startRound();
      } else if (box.style.background !== '#10B981') {
        document.getElementById('reactionMsg').innerHTML = '❌ Too early! Wait for green!';
      }
    };
    startRound();
    document.getElementById('resetReaction').onclick = () => { clearTimeout(timeout); openGame('reaction'); };
  }
  else if (gameId === 'colorswitch') {
    modalTitle.textContent = '🎨 Color Switch';
    gameContainer.innerHTML = `<div id="targetColor" style="width:100px;height:100px;margin:0 auto 20px;border-radius:20px;background:red"></div><div class="color-options" id="colorOptions"></div><p id="colorScore">Score: 0</p><button class="game-btn" id="resetColor">New Game</button>`;
    let colScore = 0;
    const colors = ['#FF2D9E', '#D946EF', '#10B981', '#F59E0B', '#3B82F6'];
    function newRound() {
      const target = colors[Math.floor(Math.random() * colors.length)];
      document.getElementById('targetColor').style.background = target;
      const optsDiv = document.getElementById('colorOptions');
      optsDiv.innerHTML = '';
      const shuffled = [...colors].sort(() => Math.random() - 0.5);
      shuffled.forEach(color => {
        const btn = document.createElement('div');
        btn.className = 'color-btn';
        btn.style.background = color;
        btn.onclick = () => {
          if (color === target) {
            colScore++;
            document.getElementById('colorScore').innerHTML = `Score: ${colScore}`;
            newRound();
          } else {
            alert('❌ Wrong color! Game Over!');
            openGame('colorswitch');
          }
        };
        optsDiv.appendChild(btn);
      });
    }
    newRound();
    document.getElementById('resetColor').onclick = () => openGame('colorswitch');
  }
  else if (gameId === 'gem') {
    modalTitle.textContent = '💎 Gem Collector';
    gameContainer.innerHTML = `<div class="gem-grid" id="gemGrid"></div><p id="gemScore">Score: 0</p><p id="gemMsg">Click gems to collect! Avoid bombs!</p><button class="game-btn" id="resetGem">New Game</button>`;
    let gemScore = 0;
    const items = ['💎', '💎', '💎', '💎', '💣', '💣', '💎', '💎', '💎', '💎', '💎', '💎', '💣', '💎', '💎', '💎'];
    const shuffled = [...items].sort(() => Math.random() - 0.5);
    const grid = document.getElementById('gemGrid');
    shuffled.forEach(item => {
      const cell = document.createElement('div');
      cell.className = 'gem-cell';
      cell.innerHTML = '?';
      cell.onclick = () => {
        if (cell.innerHTML !== '?') return;
        cell.innerHTML = item;
        if (item === '💎') {
          gemScore++;
          document.getElementById('gemScore').innerHTML = `Score: ${gemScore}`;
          document.getElementById('gemMsg').innerHTML = '✨ Got a gem! ✨';
        } else {
          document.getElementById('gemMsg').innerHTML = '💥 BOOM! Game Over!';
          setTimeout(() => openGame('gem'), 1500);
        }
      };
      grid.appendChild(cell);
    });
    document.getElementById('resetGem').onclick = () => openGame('gem');
  }
  else if (gameId === 'fish') {
    modalTitle.textContent = '🐟 Fish Eat Fish';
    gameContainer.innerHTML = `<div class="fish-area" id="fishArea"><div class="player-fish" id="playerFish">🐟</div></div><p id="fishScore">Score: 0</p><p id="fishMsg">Move mouse to eat smaller fish!</p><button class="game-btn" id="resetFish">New Game</button>`;
    let fishScore = 0;
    const area = document.getElementById('fishArea');
    const player = document.getElementById('playerFish');
    area.addEventListener('mousemove', (e) => {
      const rect = area.getBoundingClientRect();
      let x = e.clientX - rect.left - 20;
      let y = e.clientY - rect.top - 20;
      x = Math.max(0, Math.min(rect.width - 40, x));
      y = Math.max(0, Math.min(rect.height - 40, y));
      player.style.left = x + 'px';
      player.style.top = y + 'px';
    });
    function createFish() {
      const fish = document.createElement('div');
      fish.className = 'player-fish';
      fish.style.width = '25px';
      fish.style.height = '25px';
      fish.style.fontSize = '1rem';
      fish.innerHTML = '🐟';
      fish.style.left = Math.random() * (area.offsetWidth - 30) + 'px';
      fish.style.top = Math.random() * (area.offsetHeight - 30) + 'px';
      area.appendChild(fish);
      const interval = setInterval(() => {
        const pRect = player.getBoundingClientRect();
        const fRect = fish.getBoundingClientRect();
        if (Math.abs(pRect.left - fRect.left) < 30 && Math.abs(pRect.top - fRect.top) < 30) {
          fishScore++;
          document.getElementById('fishScore').innerHTML = `Score: ${fishScore}`;
          clearInterval(interval);
          fish.remove();
        }
      }, 100);
    }
    let fishInt = setInterval(createFish, 2000);
    document.getElementById('resetFish').onclick = () => { clearInterval(fishInt); openGame('fish'); };
  }
  else if (gameId === 'coin') {
    modalTitle.textContent = '🪙 Coin Runner';
    gameContainer.innerHTML = `<div class="coin-runner" id="coinArea"><div class="runner-player" id="runnerPlayer">🏃</div></div><p id="coinScore">Score: 0</p><p id="coinMsg">Move left/right to collect coins!</p><button class="game-btn" id="resetCoin">New Game</button>`;
    let coinScore = 0;
    const area = document.getElementById('coinArea');
    const player = document.getElementById('runnerPlayer');
    area.addEventListener('mousemove', (e) => {
      const rect = area.getBoundingClientRect();
      let x = e.clientX - rect.left - 20;
      x = Math.max(0, Math.min(rect.width - 40, x));
      player.style.left = x + 'px';
    });
    function createCoin() {
      const coin = document.createElement('div');
      coin.className = 'coin';
      coin.innerHTML = '🪙';
      coin.style.left = Math.random() * (area.offsetWidth - 25) + 'px';
      coin.style.top = '0px';
      area.appendChild(coin);
      let pos = 0;
      const interval = setInterval(() => {
        pos += 5;
        coin.style.top = pos + 'px';
        const pRect = player.getBoundingClientRect();
        const cRect = coin.getBoundingClientRect();
        if (Math.abs(cRect.left - pRect.left) < 40 && pos > area.offsetHeight - 60) {
          coinScore++;
          document.getElementById('coinScore').innerHTML = `Score: ${coinScore}`;
          clearInterval(interval);
          coin.remove();
        } else if (pos > area.offsetHeight) {
          clearInterval(interval);
          coin.remove();
        }
      }, 50);
    }
    let coinInt = setInterval(createCoin, 800);
    document.getElementById('resetCoin').onclick = () => { clearInterval(coinInt); openGame('coin'); };
  }
  else if (gameId === 'space') {
    modalTitle.textContent = '🔫 Space Shooter';
    gameContainer.innerHTML = `<div class="space-area" id="spaceArea"><div class="spaceship" id="spaceship">🚀</div></div><p id="spaceScore">Score: 0</p><p id="spaceMsg">Move mouse and click to shoot asteroids!</p><button class="game-btn" id="resetSpace">New Game</button>`;
    let spaceScore = 0;
    const area = document.getElementById('spaceArea');
    const ship = document.getElementById('spaceship');
    area.addEventListener('mousemove', (e) => {
      const rect = area.getBoundingClientRect();
      let x = e.clientX - rect.left - 20;
      x = Math.max(0, Math.min(rect.width - 40, x));
      ship.style.left = x + 'px';
    });
    function createAsteroid() {
      const ast = document.createElement('div');
      ast.className = 'asteroid';
      ast.innerHTML = '☄️';
      ast.style.left = Math.random() * (area.offsetWidth - 30) + 'px';
      ast.style.top = '0px';
      area.appendChild(ast);
      let pos = 0;
      const interval = setInterval(() => {
        pos += 3;
        ast.style.top = pos + 'px';
        const sRect = ship.getBoundingClientRect();
        const aRect = ast.getBoundingClientRect();
        if (Math.abs(aRect.left - sRect.left) < 40 && pos > area.offsetHeight - 60) {
          clearInterval(interval);
          ast.remove();
        } else if (pos > area.offsetHeight) {
          clearInterval(interval);
          ast.remove();
        }
      }, 50);
      area.addEventListener('click', (e) => {
        const rect = area.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const clickY = e.clientY - rect.top;
        const aRect = ast.getBoundingClientRect();
        if (Math.abs(clickX - aRect.left) < 30 && Math.abs(clickY - aRect.top) < 30) {
          spaceScore++;
          document.getElementById('spaceScore').innerHTML = `Score: ${spaceScore}`;
          clearInterval(interval);
          ast.remove();
        }
      });
    }
    let spaceInt = setInterval(createAsteroid, 1000);
    document.getElementById('resetSpace').onclick = () => { clearInterval(spaceInt); openGame('space'); };
  }
}